Description
-----------

toggle-airport is a utility that auto-disables the Mac's airport when wired ethernet is available.


Installation
------------

Download [toggle-airport.zip][], extract, then from the Terminal:
	$ sudo make install


Author
------

I did not write the script nor launch agent plist that makes this possible, I simply whipped up a quick Makefile to make the installation a bit simpler.
The script and plist file originated from [Mac OS X Hints][origin].


[origin]: http://hints.macworld.com/article.php?story=20100927161027611
